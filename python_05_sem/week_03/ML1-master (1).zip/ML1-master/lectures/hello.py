# Say hello

def greet(name):
    """ Greet the students!
    """
    print("Hello, %s!" % name)

name = "COMP 3122 students" 
greet(name)


